/**
 * 
 * @file main.cpp
 * 
 * @brief punto di accesso al programma
 * 
 * in questo file si trova il punto di accesso al programma, 
 * ovvero la funzione main, nella quale vengono chiamate
 * le funzioni create per i test.
 * 
 */


#include <iostream>
#include <vector>
#include <stdexcept>
#include <cassert>
#include "test.h"

/**
 * 
 * @brief funzione main
 * 
 * esecuzione dei test delle funzioni create
 * 
 */

int main(){

    test_fondamentali_int();
    test_fondamentali_stack();
    test_iterators_constructor_function();
    test_iterators_fill();
    test_utenti();
    test_filter_out();
    test_transform();
    test_scorri();
    test_uguaglianza_operatore();
    test_complessivo_stringhe();
    test_complessivo_animali();
    test_diversi_iteratori();

    return 0;
}