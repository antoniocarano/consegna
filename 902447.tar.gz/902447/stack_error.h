/**
 * 
 * @file stack_error.h
 * 
 * @brief File header della classe stack_error
 * 
 * File di dichiarazione della classe stack_error
 * che rappresenta un'eccezione personalizzata
 * (costum) che ha come classe base std::runtime_error
 * 
 * 
 */

#ifndef STACK_ERROR_H
#define STACK_ERROR_H

#include <stdexcept>

/**
 * 
 * @brief Classe stack_error
 * 
 * Classe che rappresenta un'eccezione personalizzata
 * (costum) che ha come classe base std::runtime_error
 * 
 */
class stack_error : public std::runtime_error {

    public:

    /**
     * 
     * @brief Costruttore di stack_error
     * 
     * Costruttore della classe stack_error
     * 
     * @param message messaggio da visualizzare
     * 
     */
        stack_error(const char* message);

};

#endif //STACK_ERROR_H