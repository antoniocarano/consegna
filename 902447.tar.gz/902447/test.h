/**
  @file tests.h

  @brief File header dei test della classe stack

  File di dichiarazioni dei test della classe stack 
*/

#ifndef STACK_TESTS_H
#define STACK_TESTS_H

#include <iostream>
#include <cassert>


/**
 * 
 * @brief Struct utente
 * 
 * struct utente che permette di creare un utente con nome e cognome
 * 
 */
struct utente {

  std::string nome;
  std::string cognome;

  utente();
  utente(const std::string &n, const std::string &c);

};

/**
 * 
 * @brief Struct animale
 * 
 * struct animale che permette di creare un animale con nome e numero di zampe
 * 
 */

struct animale {

  std::string nome;
  unsigned int zampe;

  animale();
  animale(const std::string &n, const unsigned int &z);

};

/**
 * 
 * @brief Funtore is_even
 * 
 * Funtore che restituisce true se il numero passato è pari
 *  
 */

struct is_even {
  bool operator()(int v) const {
    return (v%2)==0;
  }
};

/**
 * 
 * @brief Funtore has_feet
 * 
 * Funtore che restituisce true se l'animale passato ha zampe
 *  
 */

struct has_feet {
  bool operator()(animale &a) const {
    return a.zampe > 0;
  }
};


/**
 * 
 * @brief Funtore add_feet
 * 
 * Funtore che aggiunge 3 zampe all'animale passato 
 * (irrelistico)
 * 
 */

struct add_feet {
  animale operator()(const animale &a) const {
    return animale(a.nome, a.zampe + 3);
  }
};

/**
 * 
 * @brief Funtore start_with_letter
 * 
 * Funtore che restituisce true se la stringa passata inizia con la lettera 'a'
 * 
 */

struct start_with_letter {
  bool operator()(std::string s) const {
   return s[0] == 'a';
  }
};

/**
 * 
 * @brief Funtore change_first_letter
 * 
 * Funtore che cambia la prima lettera della stringa passata in 'A'
 * 
 */

struct change_first_letter {
  std::string operator()(std::string &s) const {
    s[0] = 'A';
    return s;
  }
};

/**
 * 
 * @brief Funtore plus_nine
 * 
 * Funtore che aggiunge 9 al numero passato
 * 
 */ 

struct plus_nine {
  int operator()(int v) const {
    return v + 9;
  }
};

/**
 * @brief test_fondamentali_int
 * 
 * Test dei metodi fondamentali della classe stack con interi
 * tra cui costruttori, operatori di assegnamento e copia
 */
void test_fondamentali_int();


/**
 * @brief test_fondamentali_stack
 * 
 * Test dei metodi fondamentali della classe stack
 */
void test_fondamentali_stack();

/**
 * @brief test_iterators_constructor_function
 * 
 * Test del costruttore con iteratori
 */
void test_iterators_constructor_function();

/**
 * @brief test_iterators_fill
 * 
 * Test del metodo fill con iteratori
 */
void test_iterators_fill();

/**
 * @brief test_utenti
 * 
 * Test con strcut utenti
 */
void test_utenti();

/**
 * @brief test_filter_out
 * 
 * Test del metodo filter_out
 */
void test_filter_out();

/**
 * @brief test_transform
 * 
 * Test del metodo transform
 */
void test_transform();

/**
 * @brief test_scorri
 * 
 * Test del metodo scorrimento stack con iteratori
 */
void test_scorri();

/**
 * @brief test_uguaglianza_operatore
 * 
 * Test con  l'operatore di uguaglianza
 * e l'uso di iteratori
 */
void test_uguaglianza_operatore();

/**
 * 
 * @brief test_complessivo_stringhe
 * 
 * test della maggior parte dei metodi,
 * costruttori e operatori effettuato sulle stringhe
 * 
 */
void test_complessivo_stringhe();

/**
 * 
 * @brief test_complessivo_animali
 * 
 * test della maggior parte dei metodi,
 * costruttori e operatori effettuato sulla struct animali
 * 
 */
void test_complessivo_animali();

/**
 * 
 * @brief test_diversi_iteratori
 * 
 * test con iterator e const_iterator
 * usando operatori, costruttori possibili
 * su due tipi diversi di dato: char e utente
 * 
 */
void test_diversi_iteratori();

#endif // STACK_TESTS_H
