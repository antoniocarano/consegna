#include "mainwindow.h"

#include <QApplication>
#include <QtDebug>


int main(int argc, char *argv[])
{
    qDebug() << "Application started.";
       QApplication a(argc, argv);
       MainWindow w;
       qDebug() << "MainWindow created.";
       w.show();
       return a.exec();
}
