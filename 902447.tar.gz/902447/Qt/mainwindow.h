#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QHeaderView>
#include <QPushButton>
#include <QFileDialog>
#include <QMessageBox>
#include <QDateTime>
#include <QSet>
#include <QFileInfo>
#include <QMap>

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    QTableWidget *logTable;
    QTimer *monitorTimer;
    QDir monitoredDir;
    QString logFilePath;
    QMap<QString, QDateTime> fileStates;
    QSet<QString> loggedFiles;
    QPushButton *saveLogButton;

    void initializeUI();
    void loadPreviousLog();
    void saveCurrentLog();
    void startMonitoring();
    void stopMonitoring();
    void checkDirectoryChanges();
    void logEvent(const QString &fileName, const QString &eventType, const QColor &color, const QDateTime &timeStamp);

private slots:
    void onSaveLogClicked();
    void onSortByColumn(int column);
    void onChooseDirectoryClicked();
};

#endif // MAINWINDOW_H
