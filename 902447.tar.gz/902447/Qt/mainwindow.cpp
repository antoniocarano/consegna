/**
 *
 * @file mainwindow.cpp
 *
 * file di implementazione delle funzioni
 * del file header.
 *
 * è consigliata la lettura della relazione (parte Qt)
 * per capire il funzionamento al 100%
 * della mia implementazione
 *
 *
 *
 *
*/


#include "mainwindow.h"

/**
 * @brief MainWindow::MainWindow costruttore
 *
 * costruttore della classe MainWindow. Inizializza l'interfaccia
 * utente e disabilita il pulsante per salvare il log
 * all'avvio poichè nessuna directory è stata selezionata
 *
 * @param parent
 *
 *
 */
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    initializeUI();
    saveLogButton->setEnabled(false);
}

/**
 * @brief MainWindow::~MainWindow distruttore
 *
 * Si occuopa della deallocazione di memoria e
 * ferma il monitraggio in corso.
 *
 */


MainWindow::~MainWindow() {
    stopMonitoring();
}

/**
 * @brief MainWindow::initializeUI impostazione interfaccia
 *
 * imposta l'interfaccia grafica:
 * 1) crea yna tabella per visualizzare gli eventi
 * 2) aggiunge i pulsanti
 * 3) collega i pulsanti alle relative funzioni
 * 4) configuara il layout
 *
 */

void MainWindow::initializeUI() {
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);

    logTable = new QTableWidget(0, 4, this);
    logTable->setHorizontalHeaderLabels({"Color", "File Name", "Event Type", "Timestamp"});
    logTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    logTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    logTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    logTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    layout->addWidget(logTable);

    QPushButton *chooseDirButton = new QPushButton("Choose Directory", this);
    layout->addWidget(chooseDirButton);
    connect(chooseDirButton, &QPushButton::clicked, this, &MainWindow::onChooseDirectoryClicked);

    saveLogButton = new QPushButton("Save Log", this);
    layout->addWidget(saveLogButton);
    connect(saveLogButton, &QPushButton::clicked, this, &MainWindow::onSaveLogClicked);

    connect(logTable->horizontalHeader(), &QHeaderView::sectionClicked, this, &MainWindow::onSortByColumn);

    setCentralWidget(centralWidget);
}


/**
 * @brief MainWindow::loadPreviousLog carica il precedente log
 *
 * carica il log precedente dal file log.txt
 * della directory selezionata:
 *
 * 1) legge il file riga per riga
 * 2) per ogni riga: estrae il nome del file, tipo di evento,
 * timeStamp e colore associato
 * 3) aggiorna lo stato dei file nella map filestate e
 * registra ogni evento nella tabella di log
 *
 */

void MainWindow::loadPreviousLog() {
    QFile file(logFilePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine();
            QStringList parts = line.split("\t");
            if (parts.size() == 4) {
                QString fileName = parts[0];
                QString eventType = parts[1];
                QDateTime timestamp = QDateTime::fromString(parts[2], "yyyy-MM-dd HH:mm:ss");
                QColor color(parts[3]);

                if (eventType == "Created" || eventType == "Modified") {
                    fileStates[fileName] = timestamp;
                } else {
                    fileStates.remove(fileName);
                }

                logEvent(fileName, eventType, color, timestamp);
                loggedFiles.insert(fileName);
            }
        }
        file.close();
    }
}


/**
 * @brief MainWindow::saveCurrentLog salva il log
 *
 * salva il log corrente in un file log.txt:
 *
 * 1) controlla che la directory esista
 * 2) scrive le informazioni della tabella nel file,
 * includendo: nome file, tipo evento, timeStamo e colore
 *
 *
 */


void MainWindow::saveCurrentLog() {
    if (!monitoredDir.exists()) {
        QMessageBox::warning(this, "Save Error", "No directory selected to save the log.");
        return;
    }

    logFilePath = monitoredDir.filePath("log.txt");
    QFile file(logFilePath);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        for (int row = 0; row < logTable->rowCount(); ++row) {
            QString fileName = logTable->item(row, 1)->text();
            QString eventType = logTable->item(row, 2)->text();
            QString timestamp = logTable->item(row, 3)->text();
            QColor color = logTable->item(row, 0)->background().color();
            out << fileName << "\t" << eventType << "\t" << timestamp << "\t" << color.name() << "\n";
        }
        file.close();
    }
}

/**
 * @brief MainWindow::startMonitoring inizio del monitoraggio
 *
 * avvia il monitoraggio della directory selezionata:
 *
 * 1) controlla che la directory esista
 * 2) crea un oggetto QTimer che chiama la funzione
 * per monitorare la directory (checkDirectoryChanges())
 * ogni 3 secondi per rilevare modifiche
 *
 */


void MainWindow::startMonitoring() {
    if (!monitoredDir.exists()) {
        QMessageBox::warning(this, "Directory Error", "The selected directory does not exist.");
        return;
    }

    monitorTimer = new QTimer(this);
    connect(monitorTimer, &QTimer::timeout, this, &MainWindow::checkDirectoryChanges);
    monitorTimer->start(3000);
}


/**
 * @brief MainWindow::stopMonitoring ferma il monitoraggio
 *
 * ferma il monitoraggio della directory:
 * se il timer è attivo, lo ferma e rilascia la memoria associata
 *
 */


void MainWindow::stopMonitoring() {
    if (monitorTimer) {
        monitorTimer->stop();
        delete monitorTimer;
        monitorTimer = nullptr;
    }
}

/**
 * @brief MainWindow::checkDirectoryChanges controlla le modifiche della directory
 *
 * controlla le modifiche della diretocry monitorata:
 * 1) confronta i file attualmente presenti con lo stato
 * precdente (salvato in fileStates)
 * 2) registra nuovi file come "created", modifiche a file
 * esistenti e file eliminati
 * 3) aggiorna la map (fileStates) con lo stato attuale dei
 * file
 *
 */


void MainWindow::checkDirectoryChanges() {
    QStringList currentFiles = monitoredDir.entryList(QDir::Files);
    QMap<QString, QDateTime> currentFileStates;

    for (const QString &file : currentFiles) {
        QFileInfo fileInfo(monitoredDir.filePath(file));
        QDateTime modifiedTime = fileInfo.lastModified();

        currentFileStates[file] = modifiedTime;

        if (!fileStates.contains(file)) {
            logEvent(file, "Created", Qt::green, modifiedTime);
        } else if (fileStates[file].toSecsSinceEpoch() != modifiedTime.toSecsSinceEpoch()){
            logEvent(file, "Modified", Qt::blue, modifiedTime);
        }
    }

    for (const QString &file : fileStates.keys()) {
        if (!currentFileStates.contains(file)) {
            logEvent(file, "Deleted", Qt::red, QDateTime::currentDateTime());
        }
    }

    fileStates = currentFileStates;
}

/**
 * @brief MainWindow::logEvent registra un evento
 *
 * registra un evento nella tabella di log
 * 1) aggiunge una nuova riga nella tabella con
 * le apposite informazioni
 * 2) imposta i colori e gli stili degli elementi
 * della tabella
 *
 * @param fileName
 * @param eventType
 * @param color
 * @param timeStamp
 */

void MainWindow::logEvent(const QString &fileName, const QString &eventType, const QColor &color, const QDateTime &timeStamp) {
    int row = logTable->rowCount();
    logTable->insertRow(row);

    QTableWidgetItem *colorItem = new QTableWidgetItem();
    QTableWidgetItem *fileNameItem = new QTableWidgetItem(fileName);
    QTableWidgetItem *eventTypeItem = new QTableWidgetItem(eventType);
    QTableWidgetItem *timestampItem = new QTableWidgetItem(timeStamp.isValid() ? timeStamp.toString("yyyy-MM-dd HH:mm:ss") : "");

    colorItem->setBackground(color);
    fileNameItem->setForeground(Qt::black);
    eventTypeItem->setForeground(Qt::black);
    timestampItem->setForeground(Qt::black);

    logTable->setItem(row, 0, colorItem);
    logTable->setItem(row, 1, fileNameItem);
    logTable->setItem(row, 2, eventTypeItem);
    logTable->setItem(row, 3, timestampItem);
}

/**
 * @brief MainWindow::onSaveLogClicked gestione salvataggio
 *
 * gestisce il click sul pulsante "save log"
 * chiamando l'apposita funzione (saveCurrentLog())
 *
 */


void MainWindow::onSaveLogClicked() {
    saveCurrentLog();
}

/**
 * @brief MainWindow::onSortByColumn ordina la tabella
 *
 * ordina la tabella in base alla colonna selezionata:
 * cliccando sull'intestazione di una colonna della tabella
 * è possibile ordinare la tabella
 *
 * @param column
 */

void MainWindow::onSortByColumn(int column) {
    logTable->sortItems(column);
}

/**
 * @brief MainWindow::onChooseDirectoryClicked
 *
 * gestisce il click sul pulsante "choose directory":
 *
 * 1) apre una finestra di dialogo per selezionare
 * una directory
 * 2) se una directory viene selezionata, imposta il percorso
 * come monitoredDir, cancella il contenuto della tabella
 * log e carica eventuali log precedenti
 * 3) avvia il monitoraggio della directory e abilita
 * il pulsante "save log"
 */

void MainWindow::onChooseDirectoryClicked() {
    QString dirPath = QFileDialog::getExistingDirectory(this, "Select Directory to Monitor", QDir::homePath());
    if (!dirPath.isEmpty()) {
        monitoredDir.setPath(dirPath);
        logFilePath = monitoredDir.filePath("log.txt");

        fileStates.clear();
        loggedFiles.clear();
        logTable->clearContents();
        logTable->setRowCount(0);

        if (QFile::exists(logFilePath)) {
            loadPreviousLog();
        }

        startMonitoring();
        saveLogButton->setEnabled(true); // Enable Save Log button after directory is chosen
    }
}
