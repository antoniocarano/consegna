/**
 * 
 * @file stack_error.cpp
 * 
 * File di implementazione della classe stack_error
 * in cui vengono implementati i metodi della classe,
 * ovvero il costruttore
 * 
 * 
 */


#include "stack_error.h"

stack_error::stack_error(const char* message) : std::runtime_error(message) {}
