/**
  @file test.cpp

  @brief File che contiene i test del codice

  File di test della classe stack 
*/

#include <iostream>
#include <cassert>
#include "stack.hpp"
#include "test.h"


utente::utente(): nome(""), cognome(""){};
utente::utente(const std::string &n, const std::string &c): nome(n), cognome(c){};

animale::animale(): nome(""), zampe(0){};
animale::animale(const std::string &n, const unsigned int &z): nome(n), zampe(z){};


/**
 * @brief test_fondamentali_int
 * 
 * Test dei metodi fondamentali della classe stack con interi
 * tra cui costruttori, operatori di assegnamento e copia
 * 
 */
void test_fondamentali_int(){

    std::cout << std::endl << "*** TEST METODI FONDAMENTALI ***" << std::endl;

    std::cout << "test ctor default" << std::endl;
    stack<int> s1;
    assert(s1.size() == 0);

    std::cout << "test ctor secondario 1" << std::endl;
    stack<int> s2(100);
    assert(s2.size() == 100);

    std::cout << "inseriti gli elementi in s1: 1, 2, 3, 4" << std::endl;

    s2.push(1);
    s2.push(2);
    s2.push(3);
    s2.push(4);

    std::cout << "test ctor di copia" << std::endl;
    stack<int> s3(s2); 

    assert(s2.size() == s3.size());
    assert(s2.top() == s3.top());

    std::cout << "test operatore assegnamento =" << std::endl;
    s1 = s2;
    assert(s1.size() == s2.size());

    std::cout << "FINE TEST" << std::endl << std::endl;
}

/**
 * @brief test_fondamentali_stack
 * 
 * Test dei metodi fondamentali della classe stack
 * 
 */
void test_fondamentali_stack(){

    std::cout << std::endl << "*** TEST METODI FONDAMENTALI STACK ***" << std::endl;

    stack<int> s2(100);
    assert(s2.size() == 100);

    std::cout << "inseriti gli elementi in s2: 1, 2, 3, 4" << std::endl;

    s2.push(1);
    s2.push(2);
    s2.push(3);
    s2.push(4);

    assert(s2.num_elements() == 4);

    std::cout << "top: " << s2.top() << std::endl;

    std::cout << "cancellati gli elementi in s2: " << std::endl;

    while(!s2.isEmpty()){
        std::cout << s2.pop() << std::endl;
    }

    assert(s2.isEmpty());
    assert(s2.num_elements() == 0);

    std::cout << "FINE TEST" << std::endl << std::endl;

}

/**
 * 
 * @brief test_iterators_constructor_funtion
 * 
 * Test del costruttore con iteratori
 * 
 */

void test_iterators_constructor_function(){

    std::cout << std::endl << "*** TEST COSTRUTTORE CON ITERATORI ***" << std::endl;

    std::cout << "inserimento degli elementi: 5, 4, 9, 10, 2" << std::endl;  

    int arr [] = {5, 4, 9, 10, 2};
    stack<int> s1(arr, arr + 5);

    assert(s1.size() == 5);

    std::cout << "pop degli elementi: " << std::endl;  
    
    while(!s1.isEmpty()){
        std::cout << s1.pop() << std::endl;
    }

    std::cout << "FINE TEST" << std::endl << std::endl;
}

/**
 * 
 *  @brief test_iterators_fill
 * 
 * Test del metodo fill con iteratori
 * 
 */

void test_iterators_fill(){

    std::cout << std::endl << "*** TEST METODO FILL CON ITERATORI ***" << std::endl;

    std::cout << "inserimento degli elementi: 1, 2, 3" << std::endl;  

    stack<int> s1(5);
    s1.push(1);
    s1.push(2);
    s1.push(3);


    int arr2 [] = {5, 4, 9 , 10, 2, 9, 12, 15, 20, 1};

    std::cout << "utilizzo della fill con 10 elementi" << std::endl;  

    try{
        s1.fill(arr2, arr2 + 10);
    }catch(stack_error &e){
        std::cout << e.what() << std::endl;
    }

    std::cout << "size: " << s1.size() << std::endl;  
    
    assert(!s1.isEmpty());

     std::cout << "utilizzo della fill con 3 elementi: 999, 98, 7" << std::endl;  

    int arr3 [] = {999, 98, 7};
    s1.fill(arr3, arr3 + 3);

    std::cout << "pop elementi 3: " << std::endl;  

     while(!s1.isEmpty()){
        std::cout << s1.pop() << std::endl;
    }

    std::cout << "FINE TEST" << std::endl << std::endl;
}


/**
 * @brief test_utenti
 * 
 * Test con strcut utenti
 */

void test_utenti(){

    std::cout << std::endl << "*** TEST METODI CON STRUCT UTENTE ***" << std::endl;

    utente utest("aldo","bianchi");

    stack<utente> s(5);

    // stack<utente> s2 = utest; --> giusto che sia errato
    s.push(utest);
    std::cout << "test value" << std::endl;
    assert(s.top().nome == "aldo");

    s.push(utente("ciro","di rosso"));
    s.push(utente("emanuele","ferrari"));

    std::cout << "test top nome value: " << s.top().nome << std::endl;
    assert(s.top().nome == "emanuele");

    std::cout << "faccio una pop" << std::endl;
    s.pop();

    assert(s.top().nome == "ciro");

    stack<utente> s2(10);

    utente utenti[] = {
        utente("Mario", "Rossi"),
        utente("Luigi", "Verdi"),
        utente("Giovanni", "Bianchi"),
        utente("Paolo", "Neri"),
        utente("Carlo", "Gialli")
    };

   s2.fill(utenti, utenti + 5);

    std::cout << "stampo gli elementi di s2" << std::endl;

    stack<utente>::const_iterator it;
    stack<utente>::const_iterator ite = s2.end();

    for(it = s2.begin(); it != ite; ++it) {
        std::cout << it->nome << " " << it->cognome << std::endl;
    }

    std::cout << "FINE TEST" << std::endl << std::endl;

}

/**
 * @brief test_filter_out
 * 
 * Test del metodo filter_out
 */

void test_filter_out(){

    std::cout << std::endl << "*** TEST FILTER OUT ***" << std::endl;
    std::cout << "inserimento degli elementi: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10" << std::endl;  

    stack<int> s(10);
    s.push(1);
    s.push(2);
    s.push(3);
    s.push(4);
    s.push(5);
    s.push(6);
    s.push(7);
    s.push(8);
    s.push(9);
    s.push(10);

    assert(s.size() == 10);
    assert(s.num_elements() == 10);


    std::cout << "creazione del nuovo stack con soli elementi pari dello stack precedente" << std::endl;  
    stack<int> s2 = s.filter_out(is_even());

    assert(s2.num_elements() == 5);

    std::cout << "cancellazione elementi dallo stack s2: " << std::endl;  

    while(!s2.isEmpty()){
        std::cout << s2.pop() << std::endl;
    }

    assert(s2.num_elements() == 0);
    assert(s2.isEmpty());

    std::cout << "FINE TEST" << std::endl << std::endl;

}



/**
 * @brief test_transform
 * 
 * Test del metodo transform
 */
void test_transform(){

    std::cout << std::endl << "*** TEST TRANSFORM ***" << std::endl;
    std::cout << "inserimento degli elementi: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10" << std::endl;  

    stack<int> s(10);
    s.push(1);
    s.push(2);
    s.push(3);
    s.push(4);
    s.push(5);
    s.push(6);
    s.push(7);
    s.push(8);
    s.push(9);
    s.push(10);

    std::cout << "trasformazione degli elementi con la funzione plus_nine (aggiunge 9 a tutti gli elementi)" << std::endl;
    transform(s, plus_nine());

    std::cout << "cancellazione elementi dallo stack s: " << std::endl;
    while(!s.isEmpty()){
        std::cout << s.pop() << std::endl;
    }

    std::cout << "FINE TEST" << std::endl << std::endl;

}

/**
 * @brief test_scorri
 * 
 * Test del metodo scorrimento stack con iteratori
 */

void test_scorri(){

    std::cout << std::endl << "*** TEST SCORRI ***" << std::endl;
    std::cout << "inserimento degli elementi: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10" << std::endl;

    stack<int> s(10);
    s.push(1);
    s.push(2);
    s.push(3);
    s.push(4);
    s.push(5);
    s.push(6);
    s.push(7);
    s.push(8);
    s.push(9);
    s.push(10);

    stack<int>::const_iterator it; 
    stack<int>::const_iterator ite; 

    ite = s.end();

    std::cout << "scorrimento dello stack con iteratori" << std::endl;

    for(it = s.begin(); it != ite; ++it) {
        std::cout << *it << std::endl;
    }

    std::cout << "FINE TEST" << std::endl << std::endl;

}


/**
 * @brief test_uguaglianza_operatore
 * 
 * Test con  l'operatore di uguaglianza
 * e l'uso di iteratori
 */

void test_uguaglianza_operatore(){

    std::cout << std::endl << "*** TEST UGUAGLIANZA OPERATORE = ***" << std::endl;
    std::cout << "inserimento degli elementi stack s3: 1, 53, 31, 2" << std::endl;

    stack<int> s3(10);
    s3.push(1); 
    s3.push(53);
    s3.push(31);
    s3.push(2);

    std::cout << "inserimento degli elementi stack s2: 99, 3" << std::endl;

    stack<int> s2(4);

    s2.push(99); 
    s2.push(3);

    std::cout << "utilizzo operatore assegnamento = (s2 = s3)" << std::endl;
    s2 = s3;

    stack<int>::const_iterator it1 = s3.begin(); 
    stack<int>::const_iterator it2 = s2.begin();

    stack<int>::const_iterator ite = s2.end();

    std::cout << "confronto degli elementi di s3 e s2" << std::endl;

    while(it2 != ite){
        std::cout << *it1 << " = " << *it2 << std::endl;
        assert(*it1 == *it2);
        ++it1;
        ++it2;
    }

    std::cout << "FINE TEST" << std::endl << std::endl;
}


/**
 * 
 * @brief test_complessivo_stringhe
 * 
 * test della maggior parte dei metodi,
 * costruttori e operatori effettuato sulle stringhe
 * 
 */
void test_complessivo_stringhe(){

    std::cout << std::endl << "*** TEST COMPLESSIVO STRINGHE ***" << std::endl;

    stack<std::string> s(5);
    s.push("antonio");
    s.push("enrico");
    s.push("luca");
    s.push("ambrogio");
    s.push("stefanio");
   
    assert(s.num_elements() == 5);

    stack<std::string> s2 = s;

    stack<std::string>::const_iterator it;
    stack<std::string>::const_iterator ite = s2.end();

    for(it = s2.begin(); it != ite; ++it) {
        std::cout << *it << std::endl;
    }

    std::cout << "svuotamento dello stack s" << std::endl;
    while(!s.isEmpty()){
        std::cout << s.pop() << std::endl;
    }
    assert(s.isEmpty());

    s = s2.filter_out(start_with_letter());

    std::cout << "stack s con solo elementi che iniziano con la lettera a" << std::endl;

    ite = s.end();

    for(it = s.begin(); it != ite; ++it) {
        std::cout << *it << std::endl;
    }

    std::cout << "trasformazione degli elementi con la funzione change_first_letter (cambia la prima lettera con A)" << std::endl;
    
    transform(s, change_first_letter());

    ite = s.end();

    for(it = s.begin(); it != ite; ++it) {
        std::cout << *it << std::endl;
    }
    
    assert(s.top() == "Ambrogio");

    std::cout << "clear dello stack s" << std::endl;
    s.clear();

    assert(s.isEmpty());

    std::string arr[] = {"male", "banana", "ciliegia", "mandarino", "kiwi", "fragola", "lampone", "arancia"};

     std::cout << "fill: ci si aspetta l'eccezione" << std::endl;
    try{
        s.fill(arr, arr + 8);
    }catch(stack_error &e){
        std::cout << e.what() << std::endl;
    }

    std::cout << "fill con 4 elementi:" << std::endl;
    s.fill(arr+2, arr + 6);

    assert(s.num_elements() == 4);
    assert(s.size() == 5);

    ite = s.end();

    for(it = s.begin(); it != ite; ++it) {
        std::cout << *it << std::endl;
    }

    std::cout << "FINE TEST" << std::endl << std::endl;
}


/**
 * 
 * @brief test_complessivo_animali
 * 
 * test della maggior parte dei metodi,
 * costruttori e operatori effettuato sulla struct animali
 * 
 */
void test_complessivo_animali(){

    std::cout << std::endl << "*** TEST COMPLESSIVO ANIMALI ***" << std::endl;

    std::cout << "test ctor default" << std::endl;
    stack<animale> s1;
    assert(s1.size() == 0);

    animale zoo[] = {
        animale("squalo", 0),
        animale("tigre", 4),
        animale("serpente", 0),
        animale("passerotto", 2),
        animale("cane", 4)
    };

     std::cout << std::endl << "test con ctr secondario" << std::endl;
    std::cout << std::endl << "inserimento di 5 animali (con fill)" << std::endl;

    stack<animale> s(5);
    s.fill(zoo, zoo + 5);

    stack<animale>::const_iterator it;
    stack<animale>::const_iterator ite = s.end();

    for(it = s.begin(); it != ite; ++it) {
        std::cout << it->nome << " con " << it->zampe << " zampe" << std::endl;
    }

    std::cout << "pop di un animale: " << std::endl;

    animale a = s.pop();
    std::cout << a.nome << " con " << a.zampe << " zampe" << std::endl;

    assert(s.num_elements() == 4);

    std::cout << "stack s con solo animali con zampe" << std::endl;

    stack<animale> s2 = s.filter_out(has_feet());

    ite = s2.end();

    for(it = s2.begin(); it != ite; ++it) {
        std::cout << it->nome << " con " << it->zampe << " zampe" << std::endl;
    }

    stack<animale> s3(10);

    s3 = s2;

    std::cout << "trasformazione degli elementi con la funzione add_feet (aggiunge 3 zampe a tutti gli animali)" << std::endl;

    transform(s3, add_feet());

    ite = s3.end();

    for(it = s3.begin(); it != ite; ++it) {
        std::cout << it->nome << " con " << it->zampe << " zampe" << std::endl;
    }

    animale zoo2[] = {
        animale("leone", 4),
        animale("elefante", 4),
        animale("giraffa", 4),
        animale("coccodrillo", 4),
        animale("orso", 4),
        animale("pinguino", 2),
        animale("canguro", 2),
        animale("struzzo", 2),
        animale("ippopotamo", 4)
    };

    std::cout << "costruttore con iteratori" << std::endl;

    stack<animale> s4(zoo2, zoo2 + 9);

    ite = s4.end();

    for(it = s4.begin(); it != ite; ++it) {
        std::cout << it->nome << " con " << it->zampe << " zampe" << std::endl;
    }

    assert(s4.top().nome == "ippopotamo");
    assert(s4.num_elements() == 9);
    assert(s4.size() == 9);

    std::cout << "svuotamento dello stack s4" << std::endl;
    while(!s4.isEmpty()){
        std::cout << s4.pop().nome << std::endl;
    }

    assert(s4.isEmpty());

    s3.clear();
    assert(s3.isEmpty());

    s3.push(animale("cavallo", 4));
    assert(s3.num_elements() == 1);
    assert(s3.size() == 5);

     std::cout << "FINE TEST" << std::endl << std::endl;

}

/**
 * 
 * @brief test_diversi_iteratori
 * 
 * test con iterator e const_iterator
 * usando operatori, costruttori possibili
 * su due tipi diversi di dato: char e utente
 * 
 */
void test_diversi_iteratori(){

    std::cout << std::endl << "*** TEST DIVERSI ITERATORI ***" << std::endl;

    stack<char> s_char(5);
    s_char.push('A');
    s_char.push('B');
    s_char.push('C');

    // Test iterator
    stack<char>::iterator it = s_char.begin();
    assert(*it == 'A');
    ++it;
    assert(*it == 'B');
    it++;
    assert(*it == 'C');

    // Test operatori di confronto
    stack<char>::iterator it2 = s_char.begin();
    assert(it != it2);
    ++it2; ++it2;
    assert(it == it2);

    // Test const_iterator
    const stack<char> s_char_const(s_char);
    stack<char>::const_iterator cit = s_char_const.begin();
    assert(*cit == 'A');
    ++cit;
    assert(*cit == 'B');
    cit++;
    assert(*cit == 'C');

    // Conversione iterator -> const_iterator
    stack<char>::const_iterator cit2 = s_char.begin();
    assert(*cit2 == 'A');

    // Test con struct utente
    stack<utente> s_utente(10);
    s_utente.push(utente("Mario", "Rossi"));
    s_utente.push(utente("Luigi", "Verdi"));
    s_utente.push(utente("Anna", "Bianchi"));

    // Test iterator su struct utente
    stack<utente>::iterator it_u = s_utente.begin();
    assert(it_u->nome == "Mario" && it_u->cognome == "Rossi");
    ++it_u;
    assert(it_u->nome == "Luigi" && it_u->cognome == "Verdi");
    it_u++;
    assert(it_u->nome == "Anna" && it_u->cognome == "Bianchi");

    // Test operatori di confronto
    stack<utente>::iterator it_u2 = s_utente.begin();
    assert(it_u != it_u2);
    ++it_u2; ++it_u2;
    assert(it_u == it_u2);

    // Test const_iterator su struct utente
    const stack<utente> s_utente_const(s_utente);
    stack<utente>::const_iterator cit_u = s_utente_const.begin();
    assert(cit_u->nome == "Mario" && cit_u->cognome == "Rossi");
    ++cit_u;
    assert(cit_u->nome == "Luigi" && cit_u->cognome == "Verdi");
    cit_u++;
    assert(cit_u->nome == "Anna" && cit_u->cognome == "Bianchi");

    // Conversione iterator -> const_iterator per struct utente
    stack<utente>::const_iterator cit_u2 = s_utente.begin();
    assert(cit_u2->nome == "Mario" && cit_u2->cognome == "Rossi");

    std::cout << "FINE TEST" << std::endl << std::endl;

}