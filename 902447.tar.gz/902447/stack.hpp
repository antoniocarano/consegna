/**
 * @file stack.hpp
 * 
 * @brief File header della classe stack implementata
 * 
 *  File di dichiarazioni/definizioni della classe stack templata
 */



#ifndef STACK_HPP
#define STACK_HPP

#include <iostream>
#include <algorithm>
#include "stack_error.h"


/**
 * 
 * @brief Classe stack
 * 
 * La classe implementa uno stack generico di elementi di tipo T.
 * Le politiche di inserimento e rimozione sono quelle tipiche di uno stack:
 * inserimento e rimozione entrambi effettuate sulla cima dello stack
 * 
 */


template <typename T>
class stack {

    public:

        typedef T value_type; // << Tipo di dato contenuto nello stack
        typedef unsigned int size_type; // << Tipo di dato per la dimensione dello stack
        typedef int top_type; // << Tipo di dato per l'indice dell'ultimo elemento inserito

    private:

        value_type *_data;  // << Puntatore all'array che contiene gli elementi dello stack
        size_type _size; // << Dimensione dell'array
        top_type _top; // << Indice dell'ultimo elemento inserito: cima dello stack


        /**
         * 
         * @brief Metodo set_default
         * 
         * Inizializza i dati membro
         * 
         * @post _data = nullptr
         * @post _size = 0
         * @post _top = -1
         * 
         */

        void set_default(){
            _data = nullptr;
            _size = 0;
            _top = -1;
        }

    public:


        /**
         * 
         * @brief Costruttore con iteratori
         * 
         * Costruttore che crea uno stack riempito con i dati presi da una
         * sequenza identidicata da un iteratore di inizio e uno di fine.
         * Gli iteratori possono essere di qualunque tipo
         * 
         * @param s iteratore di inizio
         * @param e iteratore di fine
         * 
         * @post _data != nullptr
         * @post _size = count
         * 
         * @throw std::bad_alloc possibile eccezione di allocazione
         * 
         * 
         */

        template <typename IterT>
        stack(IterT s, IterT e) : _data(nullptr), _size(0), _top(-1) {
          size_type count = 0;
           for(IterT i = s; i != e; ++i)
               ++count;

            _data = new value_type[count];
            _size = count;

            try{
                while(s!=e){
                    push(*s);
                    ++s;
                }
            }catch(...){
                delete [] _data;
                set_default();
                throw;
            }
        } 

       /**
        * 
        * @brief Costruttore di default
        * 
        * Metodo fondamantale 1:
        * Costruttore di dafault che inizializza 
        * lo stack vuoto
        * 
        * 
        * @post _data = nullptr
        * @post _size = 0
        * @post _top = -1
        * 
        */
        stack () : _data(nullptr), _size(0), _top(-1) {
            #ifndef NDEBUG 
                std::cout<<"DEFAULT COSTRUCTOR: stack ()" << std::endl;
            #endif
        }

        /**
         * 
         * @brief Costruttore secondario 
         * 
         * Costruttore secondario che permette di creare lo stack
         * della dimensione indicata
         * 
         * @param size dimensione dello stack da istanziare
         * 
         * @post _data != nullptr
         * @post _size = size
         * 
         * @throw std::bad_alloc possibile eccezione di allocazione
         * 
         */
        explicit stack (const size_type size) : _data(nullptr), _size(0), _top(-1) {
            _data = new value_type[size];
            _size = size;

            #ifndef NDEBUG 
                std::cout<<"COSTRUCTOR: stack (unsigned int size)" << std::endl;
            #endif
        }


        /**
         * 
         * @brief Costruttore di copia (Copy constructor)
         * 
         * Metodo fondamantale 4:
         * Crea uno stack a partire da un altro stack
         * 
         * @param other stack da copiare
         * 
         * @post _data != nullptr
         * @post _size = other._size
         * @post _top = other._top
         * 
         * @throw std::bad_alloc possibile eccezione di allocazione
         * 
         */
        stack (const stack &other) : _data(nullptr), _size(0), _top(-1) {
           _data = new value_type[other._size]; 
           _size = other._size;
           _top = other._top;

           try{
                for (int i = 0; i <= _top; ++i){
                    _data[i] = other._data[i];
                }
            }catch(...){
                delete [] _data;
                set_default();
                throw;
            }


            #ifndef NDEBUG 
                std::cout<<"COPY COSTRUCTOR: stack (const stack &other)" << std::endl;
            #endif
            
        }

        /**
         * 
         * @brief Operatore di assegnamento 
         * 
         * Metodo fondamentale 3:
         * Operatore che copia il contenuto di uno stack
         * nello stack corrente
         * 
         * @param other stack sorgente
         * 
         * @return reference a this
         * 
         * @post _size = other._size
         * @post _top = other._top
         * @post _data[i] = other._data[i]
         * 
         * @throw std::bad_alloc possibile eccezione di allocazione
         * 
         */
        stack &operator=(const stack &other){
            if(this != &other){
                stack tmp(other);
                this->swap(tmp);
            }

            #ifndef NDEBUG 
                std::cout<<"OPERATORE ASSEGNAMENTO: stack &operator=" << std::endl;
            #endif

            return *this;
            
        }


       /**
        * 
        * @brief Distruttore
        * 
        * Metodo fondamentale 2:
        * Il distruttore della classe rimuove eventuali risorse
        * richieste dall'oggetto
        * 
        * @post _size = 0
        * @post _top = -1
        * @post _data = nullptr
        * 
        */
        ~stack (){
            delete [] _data;
            set_default();

            #ifndef NDEBUG 
                std::cout<<"~stack ()" << std::endl;
            #endif
        }


       /**
        * 
        * @brief Metodo push
        * 
        * Inserische un elemento nello stack secondo
        * le politiche di tale struttura dati: inserimento in cima.
        * 
        * @param value valore da inserire
        * 
        * @post _top = _top + 1
        * @post _data[_top] = value
        * 
        * @throw "Stack pieno" se lo stack è pieno
        * 
        */
        void push (const value_type &value){
            if(_top == _size - 1)
                throw stack_error("Stack pieno");
            
            try{
                _data[++_top] = value;
            }catch(...){
                _top--;
                throw;
            }
        }

        /**
         * 
         * @brief Metodo pop
         * 
         * Rimuove un elemento dallo stack secondo 
         * le politiche di tale struttura dati: cancellazione in cima.
         * 
         * @post _top = _top - 1
         * 
         * @return T elemento rimosso
         * 
         * @throw "Stack vuoto" se lo stack è vuoto
         * 
         */
        value_type pop(){
            if(_top == -1)
                throw stack_error("Stack vuoto");
            
            return _data[_top--]; 
        }

        /**
         * 
         * @brief Metodo top
         * 
         * Restituisce l'elemento in cima allo stack
         * 
         * @return T elemento in cima
         * 
         * @throw "Stack vuoto" se lo stack è vuoto
         * 
         */
        const value_type& top() const {
            if(_top == -1)
                throw stack_error("Stack vuoto");
            
            return _data[_top];
        }

        /**
         * 
         * @brief Metodo size
         * 
         * Metodo che ritorna il massimo numero di 
         * elementi che lo stack puo contenere
         * 
         * @return dimensione dello stack
         * 
         */
        size_type size() const {
            return _size;
        }

        
        /**
         * 
         * @brief Metodo num_elements
         * 
         * Metodo che ritorna il numero di
         * elemeneti effettevvimanente inseriti nello stack
         * 
         * @return numero degli elementi nello stack
         * 
         */
        top_type num_elements() const {
            return _top + 1;
        }

        /**
         * 
         * @brief Controlla se lo stack è vuoto 
         * 
         * @return 1 se lo stack è vuoto, 0 altrimenti
         * 
         */
        bool isEmpty() const {
            return _top == -1;
        }

        /**
         * 
         * @brief Pulisce lo stack
         * 
         * @post _top = -1
         * 
         * 
         */
        void clear(){
            _top = -1;
        }


        /**
         * 
         * @brief Metodo swap
         * 
         * Metodo che scambia lo stato di other con quello di this
         * 
         * @param other stack con cui scambiare lo stato
         * 
         * @post this->_size == other._size
         * @post this->_top == other._top
         * @post this->_data == other._data
         * 
         * @post other._size == this->_size
         * @post other._top == this->_top
         * @post other._data == this->_data
         * 
         * 
         */
        void swap(stack &other){
            std::swap(this->_size, other._size);
            std::swap(this->_top, other._top);
            std::swap(this->_data, other._data);
        }

        /**
         * 
         * @brief Metodo fill
         * 
         * Riempie lo stack con i dati presi da una sequenza identificata
         * da un iteratore di inizio e uno di fine se la dimensione
         * della sequenza è minore o uguale alla dimensione dello stack
         * 
         * @param s iteratore di inizio
         * @param e iteratore di fine
         * 
         * @post _data != nullptr
         * @post _top = count
         * 
         * 
         * @throw "fill inappropriata: new_size > _size" se la dimensione della sequenza 
         * è maggiore della dimensione dello stack
         * @throw std::bad_alloc possibile eccezione di allocazione 
         */

        template <typename IterT>
        void fill(IterT s, IterT e){

            size_type new_size = 0;
            for(IterT i = s; i != e; ++i)
                ++new_size;
            
            if(new_size > _size)
                throw stack_error("fill inappropriata: new_size > _size");

            if(_top != -1)
                clear();


            try{
                while(s!=e){
                    push(static_cast<T>(*s));
                    ++s;
                }
            }catch(...){
                delete [] _data;
                set_default();
                throw;
            }
        }

        /**
         * 
         * @brief Metodo filter_out
         * 
         * Metodo che crea uno stack con gli elementi dello stack corrente
         * che soddisfano il predicato passato come argomento
         * 
         * @param predicate predicato da soddisfare
         * 
         * @return stack con gli elementi che soddisfano il predicato
         * 
         */
        template <typename P>
        stack filter_out(P predicate) const {
            stack result(this->_size);
            try{
                for (int i = 0; i <= _top; ++i) {
                    if (predicate(_data[i])) {
                        result.push(_data[i]);
                    }
                }
            }catch(...){
                delete [] result._data;
                result.set_default();
                throw;
            }
            return result;
        }

        class const_iterator;

        /**
         * 
         * @brief Classe iterator
         * 
         * Classe che implementa un iteratore (foreward) per la classe stack
         * 
         * 
         */
        class iterator {
            	
            public:
                typedef std::forward_iterator_tag iterator_category;
                typedef T                         value_type;
                typedef ptrdiff_t                 difference_type;
                typedef T*                        pointer;
                typedef T&                        reference;

        
                iterator(): _ptr(nullptr) {}
                
                iterator(const iterator &other) : _ptr(other._ptr) {}

                iterator& operator=(const iterator &other) {
                    _ptr = other._ptr;
                    return *this;
                }

                ~iterator() {
                    _ptr = nullptr;
                }

                // Ritorna il dato riferito dall'iteratore (dereferenziamento)
                reference operator*() const {
                    return *_ptr;
                }

                // Ritorna il puntatore al dato riferito dall'iteratore
                pointer operator->() const {
                    return _ptr;
                }

                // Operatore di iterazione post-incremento
                iterator operator++(int) {
                    iterator temp(*this);
                    ++(*this);
                    return temp;
                }

                // Operatore di iterazione pre-incremento
                iterator& operator++() {
                    ++_ptr;
                    return *this;
                }

                // Uguaglianza
                bool operator==(const iterator &other) const {
                    return _ptr == other._ptr;
                }

                // Diversita'
                bool operator!=(const iterator &other) const {
                    return _ptr != other._ptr;
                }
                
                // Solo se serve anche const_iterator aggiungere le seguenti definizioni
                friend class const_iterator;

                // Uguaglianza
                bool operator==(const const_iterator &other) const {
                    return _ptr == other._ptr;
                }

                // Diversita'
                bool operator!=(const const_iterator &other) const {
                    return _ptr != other._ptr;
                }

               

            private:
                //Dati membro
                T *_ptr;
                
                friend class stack; 

                // Costruttore privato di inizializzazione usato dalla classe container
                // tipicamente nei metodi begin e end
                iterator(T *p) : _ptr(p){ 
                    
                }
                
               
                
        }; // classe iterator

        // Ritorna l'iteratore all'inizio della sequenza dati
        iterator begin() {
            return iterator(_data);
        }
        
        // Ritorna l'iteratore alla fine della sequenza dati
        iterator end() {
            return iterator(_data+ (_top + 1));
        }

        /**
         * 
         * @brief classe const_iterator
         * 
         * Classe che implementa un iteratore costante per la classe stack
         * 
         */

        class const_iterator {
		
        public:
            typedef std::forward_iterator_tag iterator_category;
            typedef T                         value_type;
            typedef ptrdiff_t                 difference_type;
            typedef const T*                  pointer;
            typedef const T&                  reference;

        
            const_iterator() : _ptr(nullptr) { }
            
            const_iterator(const const_iterator &other) : _ptr(other._ptr) { }

            const_iterator& operator=(const const_iterator &other) {
                _ptr = other._ptr;
                return *this;
            }

            ~const_iterator() {
               _ptr = nullptr;
            }

            // Ritorna il dato riferito dall'iteratore (dereferenziamento)
            reference operator*() const {
                return *_ptr;
            }

            // Ritorna il puntatore al dato riferito dall'iteratore
            pointer operator->() const {
               return _ptr;
            }
            
            // Operatore di iterazione post-incremento
            const_iterator operator++(int) {
                const_iterator temp(*this);
                ++_ptr;
                return temp;
            }

            // Operatore di iterazione pre-incremento
            const_iterator& operator++() {
                ++_ptr;
                return *this;
            }

            // Uguaglianza
            bool operator==(const const_iterator &other) const {
                 return _ptr == other._ptr;
            }
            
            // Diversita'
            bool operator!=(const const_iterator &other) const {
                return _ptr != other._ptr;
            }

           
            
            friend class iterator;

            // Uguaglianza
            bool operator==(const iterator &other) const {
               return _ptr == other._ptr;
            }

            // Diversita'
            bool operator!=(const iterator &other) const {
                return _ptr != other._ptr;
            }

            // Costruttore di conversione iterator -> const_iterator
            const_iterator(const iterator &other) : _ptr(other._ptr) {
            }

            // Assegnamento di un iterator ad un const_iterator
            const_iterator &operator=(const iterator &other) {
                _ptr = other._ptr;
                return *this;
            }

            // Solo se serve anche iterator aggiungere le precedenti definizioni

        private:
            //Dati membro
            const T *_ptr;

            
            // usare il costruttore di inizializzazione.
            friend class stack; 

            // Costruttore privato di inizializzazione usato dalla classe container
            // tipicamente nei metodi begin e end
            const_iterator (const T*p) : _ptr(p) { }
            
           
            
        }; // classe const_iterator
        
        // Ritorna l'iteratore all'inizio della sequenza dati
        const_iterator begin() const {
            return const_iterator(_data);
        }
        
        // Ritorna l'iteratore alla fine della sequenza dati
        const_iterator end() const {
            return const_iterator(_data+ (_top+1));
        }
};


/**
 * 
 * @brief Funzione transform
 * 
 * Trasforma tutti i valori contenuti nello stack, passato nei parametri,
 * utilizzando il funtore, anch'esso indicato nei parametri, 
 * sovrascrivendoli
 * 
 * @param s Stack a cui modificare i valori
 * @param functor Funtore da utilizzare per la trasformazione
 * 
 *   
 * @post s[i] = functor(s[i]) per ogni i
 * 
 * 
 */
template <typename T, typename F>
void transform(stack<T> &s, F functor) {

    typename stack<T>::iterator i, e;
    for(i = s.begin(), e = s.end(); i != e; ++i){
        *i = functor(*i);
    }
}


#endif // STACK_HPP